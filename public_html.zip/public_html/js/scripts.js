

// auto update copyright

function copyrightYear() {
    document.write(new Date().getFullYear());
}